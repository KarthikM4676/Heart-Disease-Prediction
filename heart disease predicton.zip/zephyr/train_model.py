import os
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import pickle
import subprocess
import zipfile
import glob

# Step 1: Check if CSV already exists
zip_path = "heart-disease-data.zip"
csv_files = glob.glob("*.csv")

if not csv_files:
    print("Downloading dataset from Kaggle...")
    subprocess.run([
        "C:/Users/LENOVO/AppData/Roaming/Python/Python312/Scripts/kaggle.exe",
        "datasets", "download", "-d", "redwankarimsony/heart-disease-data"
    ])
    
    # Step 2: Extract ZIP
    if os.path.exists(zip_path):
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(".")
        print("Dataset downloaded and extracted.")
    else:
        raise FileNotFoundError("ZIP file was not downloaded properly.")

# Step 3: Locate CSV file
csv_files = glob.glob("*.csv")
if not csv_files:
    raise FileNotFoundError("No CSV dataset found after extraction.")

dataset_path = csv_files[0]
print(f"Using dataset: {dataset_path}")

# Step 4: Load dataset
df = pd.read_csv(dataset_path)
print("Columns in dataset:", df.columns.tolist())

# Step 5: Encode all categorical columns
label_encoder = LabelEncoder()

# Encode any categorical column in the dataset
categorical_columns = df.select_dtypes(include=['object']).columns.tolist()
for col in categorical_columns:
    df[col] = label_encoder.fit_transform(df[col])

# Step 6: Split data into features and target
target_col = 'num'  # This is the actual target column in the dataset
X = df.drop([target_col, 'id', 'dataset'], axis=1, errors='ignore')  # Optional: Drop irrelevant cols
y = df[target_col]

# Step 7: Train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Step 8: Save model
os.makedirs("model", exist_ok=True)
with open("model/heart_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("✅ Model trained and saved to model/heart_model.pkl")
