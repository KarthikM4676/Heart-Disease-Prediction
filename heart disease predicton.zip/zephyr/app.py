from flask import Flask, render_template, request, redirect, url_for, session
import pickle
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key'  # Replace with a strong secret key

model_path = os.path.join("model", "heart_model.pkl")

# Load the model
with open(model_path, 'rb') as f:
    model = pickle.load(f)

# In-memory user store 
users = {}

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        if not username or not password:
            return "Please enter username and password"
        if username in users:
            return "Username already exists, please choose another."
        users[username] = password
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        if users.get(username) == password:
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            return "Invalid credentials or user does not exist."
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return render_template('dashboard.html', username=session['username'], time=current_time)

@app.route('/predict-form')
def predict_form():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'username' not in session:
        return redirect(url_for('login'))

    try:
        data = request.form
        features = [
            int(data['age']),
            1 if data['sex'].lower() == 'male' else 0,
            int(data['cp']),
            int(data['trestbps']),
            int(data['chol']),
            1 if data['fbs'].lower() == 'yes' else 0,
            int(data['restecg']),
            int(data['thalch']),
            1 if data['exang'].lower() == 'yes' else 0,
            float(data['oldpeak']),
            int(data['slope']),
            int(data['ca']),
            int(data['thal'])
        ]

        prediction = model.predict([features])[0]
        result = "Positive for heart disease" if prediction else "🟢 No heart disease detected"

        return render_template('index.html', prediction_text=result)
    except Exception as e:
        return render_template('index.html', prediction_text=f"Error: {e}")

if __name__ == '__main__':
    app.run(debug=True)
